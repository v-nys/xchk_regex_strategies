import unittest
import datetime
from unittest.mock import MagicMock
from django.test import TestCase
from xchk_regex_strategies.strats import RegexCheck
from xchk_core.strats import OutcomeAnalysis, OutcomeComponent
from xchk_core.models import SubmissionV2

# tests go here
class RegexMatchingTest(TestCase):

    def test_matching_string(self):
        chk = RegexCheck(pattern=r'a[bc]d+e')
        mock_open = MagicMock()
        mock_open.__enter__.read().return_value = 'acdddddddde'
        submission = SubmissionV2(content_uid='some_uid')
        # checksum = models.CharField(max_length=40,null=True)
        # timestamp = models.DateTimeField()
        # repo = models.ForeignKey(Repo, null=False, on_delete=models.CASCADE)
        # state = enum.EnumField(SubmissionState, default=SubmissionState.PENDING)
        # submitter = models.ForeignKey(settings.AUTH_USER_MODEL, null=False, on_delete=models.CASCADE)
        # feedback = models.TextField(null=True,blank=True)
        # content_uid = models.CharField(max_length=40,null=False)
        analysis = chk.check_submission(submission=submission,student_path='studentfile.txt',model_path='/home/model.regex',desired_outcome=True,init_check_number=1,parent_is_negation=False,open=mock_open)
        expected = OutcomeAnalysis(outcome=True,outcomes_components=[OutcomeComponent(component_number=1,outcome=True,desired_outcome=True,renderer=None,renderer_data=None,rendered_data=None)])
        self.AssertEqual(analysis,expected)

#    def test_nonmatching_string_single_line(self):
#        chk = RegexCheck(pattern=r'a[bc]d+e')
#        analysis = chk.check_submission(submission,'studentfile.txt','/home/model.regex',True,1,False,mock_open)
#        self.AssertEqual(analysis,expected)
#
#    def test_nonmatching_string_multiple_lines(self):
#        chk = RegexCheck(pattern=r'a[bc]d+e')
#        analysis = chk.check_submission(submission,'studentfile.txt','/home/model.regex',True,1,False,mock_open)
#        self.AssertEqual(analysis,expected)

if __name__ == '__main__':
    unittest.main()
