from django.apps import AppConfig


class RegexstrategiesConfig(AppConfig):
    name = 'xchk_regex_strategies'
