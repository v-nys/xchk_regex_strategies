import unittest
from django.test import TestCase

# tests go here

if __name__ == '__main__':
    unittest.main()
